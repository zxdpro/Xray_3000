<div align="center">
<img src=wechat.jpg width="60%"/>

<p> 扫码关注公众号，加入「ChatGLM交流群」 </p>
<p> Scan the QR code to follow the official account and join the "ChatGLM Discussion Group" </p>
</div>
